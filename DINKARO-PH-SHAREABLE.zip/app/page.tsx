"use client";
import {useState} from "react";

const nav=[
 ["dashboard","Dashboard","⌂"],["players","Players","♙"],["courts","Courts","▦"],
 ["open","Open Play","◉"],["tournaments","Tournaments","🏆"],["live","Live Tournament","●"],["rankings","Rankings","↗"]
];

export default function Home(){
 const [page,setPage]=useState("dashboard");
 const [players,setPlayers]=useState([
  {name:"Jonel Espora",level:"Intermediate",rating:3.5,matches:28,wins:19},
  {name:"Marco Reyes",level:"Advanced",rating:4.0,matches:35,wins:25},
  {name:"Kevin Santos",level:"Intermediate",rating:3.25,matches:21,wins:12}
 ]);
 const [matches,setMatches]=useState([
  {court:"Court 1",a:"Espora / Reyes",b:"Santos / Cruz",sa:11,sb:8},
  {court:"Court 2",a:"Dela Cruz / Lim",b:"Garcia / Tan",sa:7,sb:9},
  {court:"Court 3",a:"Rivera / Ong",b:"Mendoza / Yap",sa:0,sb:0}
 ]);
 const [modal,setModal]=useState(false);

 function addPlayer(){
  const name=prompt("Player name");
  if(name) setPlayers([...players,{name,level:"Intermediate",rating:3,matches:0,wins:0}]);
 }
 function score(i:number,side:"a"|"b"){
  setMatches(matches.map((m,x)=>x===i?{...m,[side==="a"?"sa":"sb"]:m[side==="a"?"sa":"sb"]+1}:m));
 }
 return <div className="app">
  <aside>
   <div className="brand">DINKARO <span>PH</span></div><small>PLAY. MANAGE. CONNECT.</small>
   <nav>{nav.map(n=><button className={page===n[0]?"active":""} onClick={()=>setPage(n[0])} key={n[0]}><i>{n[2]}</i>{n[1]}</button>)}</nav>
   <div className="admin"><b>JE</b><div>Jonel Espora<small>Administrator</small></div></div>
  </aside>
  <main>
   <header><div><label>DINKARO PH • PICKLEBALL MANAGEMENT</label><h1>{nav.find(n=>n[0]===page)?.[1]}</h1><p>Play. Manage. Connect.</p></div><button className="primary" onClick={()=>setModal(true)}>＋ Create New</button></header>
   {page==="dashboard"&&<Dashboard players={players} matches={matches} setPage={setPage}/>}
   {page==="players"&&<Players players={players} addPlayer={addPlayer}/>}
   {page==="courts"&&<Courts/>}
   {page==="open"&&<OpenPlay/>}
   {page==="tournaments"&&<Tournaments/>}
   {page==="live"&&<Live matches={matches} score={score}/>}
   {page==="rankings"&&<Rankings players={players}/>}
   {modal&&<div className="modal"><div><button className="close" onClick={()=>setModal(false)}>×</button><h2>Create in DINKARO PH</h2><p>Choose the module you want to create from the navigation menu.</p><button className="primary" onClick={()=>{setModal(false);setPage("open")}}>Create Open Play</button></div></div>}
  </main>
 </div>
}

function Dashboard({players,matches,setPage}:any){return <><section className="hero"><div><label>● SYSTEM ONLINE</label><h2>Welcome to <em>DINKARO PH</em></h2><p>A complete starting point for managing players, courts, open play, tournaments and live scoring.</p><button className="primary" onClick={()=>setPage("open")}>Start Managing</button></div><strong>🏓</strong></section><div className="stats"><Stat n={players.length} t="Registered Players"/><Stat n="6" t="Active Courts"/><Stat n="12" t="Open Play Sessions"/><Stat n={matches.length} t="Live Matches"/></div><div className="grid"><Box title="Today's Activity"><Row t="Friday Open Play" s="Court 1 • 4:00 PM – 7:00 PM"/><Row t="Intermediate Night" s="Court 3 • 6:00 PM – 9:00 PM"/><Row t="Tournament Match" s="Court 2 • LIVE"/></Box><Box title="Quick Actions"><div className="quick"><button onClick={()=>setPage("open")}>🎾 Create Open Play</button><button onClick={()=>setPage("courts")}>🏟 Manage Courts</button><button onClick={()=>setPage("tournaments")}>🏆 Create Tournament</button><button onClick={()=>setPage("players")}>👤 Add Player</button></div></Box></div></>}
function Stat({n,t}:any){return <div className="stat"><b>{n}</b><span>{t}</span></div>}
function Box({title,children}:any){return <section className="box"><h3>{title}</h3>{children}</section>}
function Row({t,s}:any){return <div className="row"><b>{t}<small>{s}</small></b><span>OPEN</span></div>}

function Players({players,addPlayer}:any){return <section className="box"><div className="bar"><h3>Players</h3><button className="primary" onClick={addPlayer}>＋ Add Player</button></div><table><thead><tr><th>Player</th><th>Level</th><th>Rating</th><th>Matches</th><th>Win Rate</th></tr></thead><tbody>{players.map((p:any,i:number)=><tr key={i}><td><b>{p.name}</b></td><td>{p.level}</td><td>{p.rating.toFixed(2)}</td><td>{p.matches}</td><td>{p.matches?Math.round(p.wins/p.matches*100):0}%</td></tr>)}</tbody></table></section>}
function Courts(){return <div className="cards">{["Court 1","Court 2","Court 3","Court 4","Court 5","Court 6"].map((c,i)=><section className="box court" key={c}><div>🏟️</div><h3>{c}</h3><p>DINKARO Arena</p><span className={i===1?"busy":"available"}>{i===1?"Occupied":"Available"}</span></section>)}</div>}
function OpenPlay(){return <div className="cards">{["Friday Open Play","Intermediate Night","Beginner Friendly"].map((x,i)=><section className="box" key={x}><span className="tag">ALL LEVELS</span><h3>{x}</h3><p>🏟 Court {i+1}<br/>🕒 {i+4}:00 PM – 7:00 PM</p><div className="progress"><span style={{width:(45+i*18)+"%"}}/></div><small>{8+i}/12 players registered</small><button className="secondary">View Session</button></section>)}</div>}
function Tournaments(){return <div className="grid"><section className="box big"><label>TOURNAMENT CENTER</label><h2>DINKARO PH Opening Cup</h2><p>Create divisions, registration, brackets, match schedules and results.</p><div className="steps"><b>1 Setup</b><b>2 Registration</b><b>3 Bracket</b><b>4 Live Scoring</b></div><button className="primary">＋ Create Tournament</button></section><section className="box"><h3>Upcoming</h3><Row t="DINKARO PH Opening Cup" s="Open • 16 Teams"/><Row t="Saturday Doubles" s="Intermediate • 12 Teams"/></section></div>}
function Live({matches,score}:any){return <div><section className="box"><label>● LIVE TOURNAMENT TV</label><h2>Live Court Scores</h2><p>Scores update instantly on this screen.</p></section><div className="livegrid">{matches.map((m:any,i:number)=><section className="match" key={m.court}><div className="matchtop"><b>{m.court}</b><span>LIVE</span></div><div>{m.a}<strong>{m.sa}</strong><button onClick={()=>score(i,"a")}>+</button></div><div>{m.b}<strong>{m.sb}</strong><button onClick={()=>score(i,"b")}>+</button></div></section>)}</div></div>}
function Rankings({players}:any){return <section className="box"><h3>Player Rankings</h3>{[...players].sort((a,b)=>b.rating-a.rating).map((p:any,i:number)=><div className="rank" key={p.name}><b>#{i+1}</b><span>{p.name}</span><small>{p.level}</small><strong>{p.rating.toFixed(2)}</strong></div>)}</section>}
