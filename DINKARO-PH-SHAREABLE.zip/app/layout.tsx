import "./globals.css";
export const metadata={title:"DINKARO PH | Pickleball Management",description:"Play. Manage. Connect."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}