# DINKARO PH — Shareable Starter

## Run locally
npm install
npm run dev

Open http://localhost:3000

## Share online
This project is structured for GitHub + Vercel deployment.

1. Upload the project files to a GitHub repository.
2. Import the repository into Vercel.
3. Deploy.
4. Vercel gives you a public HTTPS link you can share.

## Included
Dashboard, Players, Courts, Open Play, Tournaments, Live Tournament scoring and Rankings.

The current data is demo/browser-local data. Production accounts, cloud database, authentication and real-time multi-user syncing need to be connected before public production use.
